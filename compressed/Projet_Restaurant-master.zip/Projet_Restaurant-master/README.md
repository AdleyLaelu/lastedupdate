# Projet_Restaurant

## Description
Premier projet réalisé pendant la formation Becode (Bruxelles).
Nous devions créer un site vitrine d'une franchise fictive de restaurants. 
Minimum 5 pages accessibles par une barre de navigation présente sur toutes les pages vers les différentes rubriques : Accueil, Carte, Photos, Restaurants, Contact. 

## Comment ?

En utilisant HTML, CSS, Bootstrap. (pas de PHP)

## Par qui ?

>Antoni Dalle Nogare
[Github] https://github.com/tonidano

## Deployment

Via github page

> https://tonidano.github.io/Projet_Restaurant/

## Audit

>[Test Lightouse]
<img src="/images/test-lighthouse.PNG" alt=""/>
